<?php

$host = "localhost";
$user = "root";
$pass = "";
$database = "valpoint";

//$conn = mysqli_connect($host, $user, $pass, $database);

//$conn;

?>